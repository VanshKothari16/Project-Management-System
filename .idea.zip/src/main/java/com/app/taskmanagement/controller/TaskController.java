package com.app.taskmanagement.controller;

import com.app.taskmanagement.enums.Status;
import com.app.taskmanagement.requestdto.TaskRequestDto;
import com.app.taskmanagement.responsedto.AdminDashboardDto;
import com.app.taskmanagement.responsedto.ManagerTaskResponseDto;
import com.app.taskmanagement.responsedto.TaskResponseDto;
import com.app.taskmanagement.services.TaskServices;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/task_management/task")
@RequiredArgsConstructor
public class TaskController {
    private final TaskServices taskServices;

    @PreAuthorize("CRUD_TASK")
    @PostMapping
    public ResponseEntity<TaskResponseDto> addTask(@RequestBody TaskRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(taskServices.addTask(dto));
    }

    @PreAuthorize("CRUD_TASK")
    @PostMapping("/assign")
    public ResponseEntity<String> assignTaskToEmployee(@RequestParam String task, @RequestParam String email) {
        return ResponseEntity.ok(taskServices.assignTaskToEmployee(task, email));
    }

    @PreAuthorize("CRUD_TASK")
    @GetMapping("/{id}")
    public ResponseEntity<TaskResponseDto> getTask(@PathVariable("id") String id) {
        return ResponseEntity.ok(taskServices.getTask(id));
    }


    @PreAuthorize("CRUD_TASK")
    @GetMapping("/all")
    public ResponseEntity<List<ManagerTaskResponseDto>> getAllTask() {
        return ResponseEntity.ok(taskServices.findAll());
    }

    @PreAuthorize("CRUD_TASK")
    @PutMapping
    public ResponseEntity<TaskResponseDto> updateTask(@RequestBody TaskRequestDto dto, @RequestParam String id) {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(taskServices.updateTask(dto, id));
    }

    @PreAuthorize("CRUD_TASK")
    @DeleteMapping
    public ResponseEntity<?> deleteTask(@RequestParam String id) {
        taskServices.deleteTask(id);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(
                "Successfully deleted!"
        );
    }

    @PreAuthorize("ROLE_MANAGER")
    @PostMapping("/{id}")
    public ResponseEntity<?> MarkTaskCompleted(@PathVariable("id") String id) {
        taskServices.markItAsCompleted(id);
        return ResponseEntity.ok("Task Status changed to COMPLETED!");
    }

    //*********** Manager and ADMIN Dashboard **************
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_MANAGER')")
    @GetMapping("/overdue")
    public ResponseEntity<List<ManagerTaskResponseDto>> getAllOverDueTask() {
        return ResponseEntity.ok(taskServices.findAllOverdueTask());
    }


    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_MANAGER')")
    @GetMapping("/todo")
    public ResponseEntity<List<ManagerTaskResponseDto>> getAllToDoTask() {
        return ResponseEntity.ok(taskServices.findAllTaskByStatus(Status.TO_DO));
    }


    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_MANAGER')")
    @GetMapping("/inprogress")
    public ResponseEntity<List<ManagerTaskResponseDto>> getAllInProgressTask() {
        return ResponseEntity.ok(taskServices.findAllTaskByStatus(Status.IN_PROGRESS));
    }


    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_MANAGER')")
    @GetMapping("/completed")
    public ResponseEntity<List<ManagerTaskResponseDto>> getAllCompletedTask() {
        return ResponseEntity.ok(taskServices.findAllTaskByStatus(Status.COMPLETED));
    }


    @PreAuthorize("ROLE_ADMIN")
    @GetMapping("/completed")
    public ResponseEntity<AdminDashboardDto> getAdminDashboard() {
        return ResponseEntity.ok(taskServices.getAdminDashboardDto());
    }

    //******** Only for Employee Dashboard *********
    @PreAuthorize("hasAnyAuthority('ROLE_EMPLOYEE','ROLE_MANAGER')")
    @GetMapping("/employee/all")
    public ResponseEntity<List<TaskResponseDto>> getAllTaskOfEmployee() {
        return ResponseEntity.ok(taskServices.getTaskOfEmployee());
    }

    @PreAuthorize("hasAnyAuthority('ROLE_EMPLOYEE','ROLE_MANAGER')")
    @GetMapping("/employee/todo")
    public ResponseEntity<List<TaskResponseDto>> getToDoTaskOfEmployee() {
        return ResponseEntity.ok(taskServices.getTaskOfEmployeeByStatus(Status.TO_DO));
    }

    @PreAuthorize("hasAnyAuthority('ROLE_EMPLOYEE','ROLE_MANAGER')")
    @GetMapping("/employee/inprogress")
    public ResponseEntity<List<TaskResponseDto>> getInProgressTaskOfEmployee() {
        return ResponseEntity.ok(taskServices.getTaskOfEmployeeByStatus(Status.IN_PROGRESS));
    }

    @PreAuthorize("hasAnyAuthority('ROLE_EMPLOYEE','ROLE_MANAGER')")
    @GetMapping("/employee/completed")
    public ResponseEntity<List<TaskResponseDto>> getCompletedTaskOfEmployee() {
        return ResponseEntity.ok(taskServices.getTaskOfEmployeeByStatus(Status.COMPLETED));
    }

}
