package com.app.taskmanagement.services;

import com.app.taskmanagement.entity.User;
import com.app.taskmanagement.repository.UserRepository;
import com.app.taskmanagement.requestdto.LoginDto;
import com.app.taskmanagement.requestdto.UserRequestDto;
import com.app.taskmanagement.responsedto.UserResponseDto;
import com.app.taskmanagement.utils.JwtServices;
import com.app.taskmanagement.utils.Mapper;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserServices {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationProvider authenticationProvider;
    private final JwtServices jwtServices;

    public UserServices(UserRepository userRepository, PasswordEncoder passwordEncoder, AuthenticationProvider authenticationProvider, JwtServices jwtServices) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationProvider = authenticationProvider;
        this.jwtServices = jwtServices;
    }

    public UserResponseDto register(UserRequestDto requestDto) {
        User exist = userRepository.findByEmail(requestDto.getEmail());
        if (exist != null) throw new RuntimeException("You already have an account!");

        User user = Mapper.toUserEntity(requestDto);
        user.setPassword(encodePassword(requestDto.getPassword()));

        user=userRepository.save(user);
        return Mapper.toUserResponseDto(
                user
        );
    }

    public String login(LoginDto loginDto) {
        Authentication authentication = new UsernamePasswordAuthenticationToken(
                loginDto.getUsername(), loginDto.getPassword()
        );

        Authentication authResult = authenticationProvider.authenticate(authentication);

        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(authResult);
        SecurityContextHolder.setContext(context);

        return jwtServices.generateToken((UserDetails) authResult.getPrincipal());

    }

    private String encodePassword(String password) {
        return passwordEncoder.encode(password);
    }
}
