package com.app.taskmanagement.controller;

import com.app.taskmanagement.requestdto.EmployeeRequestDto;
import com.app.taskmanagement.responsedto.EmployeeResponseDto;
import com.app.taskmanagement.services.EmployeeServices;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/task_management/employee")
@RequiredArgsConstructor
@Validated
public class EmployeeController {
    private final EmployeeServices services;

    @PostMapping
    public ResponseEntity<EmployeeResponseDto> register(@Valid @RequestBody EmployeeRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(services.addEmployee(dto));
    }

    @PreAuthorize("hasAnyAuthority('ROLE_MANAGER','ROLE_ADMIN')")
    @PutMapping
    public ResponseEntity<EmployeeResponseDto> update(@Valid @RequestBody EmployeeRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(services.update(dto));
    }

    @PreAuthorize("hasAnyAuthority('ROLE_MANAGER','ROLE_ADMIN')")
    @GetMapping
    public ResponseEntity<EmployeeResponseDto> get() {
        return ResponseEntity.status(HttpStatus.CREATED).body(services.getEmployee());
    }

    @PreAuthorize("hasAuthority('ROLE_MANAGER','ROLE_ADMIN')")
    public ResponseEntity<List<String>> getAllEmployeeEmails(){
        return ResponseEntity.ok(services.getAllEmployeeEmails());
    }
}
