package com.app.taskmanagement.services;

import com.app.taskmanagement.entity.Commitments;
import com.app.taskmanagement.entity.Employee;
import com.app.taskmanagement.entity.Task;
import com.app.taskmanagement.repository.CommitmentsRepository;
import com.app.taskmanagement.repository.EmployeeRepository;
import com.app.taskmanagement.repository.TaskRepository;
import com.app.taskmanagement.requestdto.CommitmentRequestDto;
import com.app.taskmanagement.responsedto.CommitmentResponseDto;
import com.app.taskmanagement.utils.Mapper;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.channels.AcceptPendingException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CommitmentServices {
    private final CommitmentsRepository commitmentsRepository;
    private final TaskRepository taskRepository;
    private final EmployeeRepository employeeRepository;
    private final TaskServices taskServices;

    public CommitmentResponseDto addCommits(CommitmentRequestDto commitmentRequestDto) {
        Employee employee = getCurrentUser();
        Task t1 = taskRepository.findById(commitmentRequestDto.getTaskId()).orElseThrow(
                () -> new RuntimeException("Invalid Task Id!")
        );
        Commitments commit = Commitments.builder()
                .commitments(commitmentRequestDto.getCommitment())
                .task(t1)
                .createdBy(employee)
                .build();

        commit = commitmentsRepository.save(commit);
        taskServices.changeStatusToIn_Progress(t1.getId());

        return Mapper.toCommitmentResponseDto(commit);
    }

    public CommitmentResponseDto editCommits(CommitmentRequestDto dto, String commitId) {
        Employee employee = getCurrentUser();
        Task t1 = taskRepository.findById(dto.getTaskId()).orElseThrow(
                () -> new RuntimeException("Invalid Task Id!")
        );

        Commitments commit = commitmentsRepository.findById(commitId).orElseThrow(
                () -> new RuntimeException("Invalid commitment Id!")
        );

        commit.setCommitments(dto.getCommitment());

        commitmentsRepository.flush();
        return Mapper.toCommitmentResponseDto(commit);
    }

    public void deleteCommits(String commitId) {
        Employee emp = getCurrentUser();
        Commitments commitments = commitmentsRepository.findById(commitId).orElseThrow(
                () -> new RuntimeException("Invalid Commitments Id!")
        );

        if (!emp.getEmail().equals(commitments.getCreatedBy().getEmail()))
            throw new AcceptPendingException();
        commitmentsRepository.delete(commitments);
    }

    public Page<CommitmentResponseDto> getAllCommitmentsOfTask(String taskId, int page, int size) {
        Sort sort = Sort.by(Sort.Direction.ASC, "createdAt");
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<Commitments> commitmentsPage = commitmentsRepository.findCommitmentsByTaskId(taskId, pageable);
        return commitmentsPage.map(Mapper::toCommitmentResponseDto);
    }


    private Employee getCurrentUser() {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return employeeRepository.findByEmail(userDetails.getUsername()).get();
    }
}
