package com.app.taskmanagement.repository;

import com.app.taskmanagement.entity.Task;
import com.app.taskmanagement.enums.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface TaskRepository extends JpaRepository<Task, String> {

    @Query("FROM Task t WHERE t.title = :title AND t.projects.id = :id")
    Optional<Task> findByTitleAndProjects(@Param("title") String title, @Param("id") String projectId);

    @Query("SELECT t FROM Task t JOIN t.employee e WHERE e.email = :email")
    List<Task> findTaskOfEmployee(@Param("email") String email);

    @Query("SELECT t FROM Task t WHERE t.status = :status AND t.projects.id = :id")
    List<Task> findTaskByStatusAndProjects(@Param("status") Status status, @Param("id") String projectId);

    @Query("FROM Task t WHERE t.projects.id = :id")
    List<Task> findTaskByProjects(@Param("id") String id);

    @Query("SELECT t, SIZE(t.commitments) FROM Task t WHERE t.projects.id = :projectId")
    List<Object[]> findTasksWithCommitmentCount(@Param("projectId") String projectId);
}
