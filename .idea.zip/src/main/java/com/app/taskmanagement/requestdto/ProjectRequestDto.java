package com.app.taskmanagement.requestdto;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProjectRequestDto {
    private String name;
    private String description;
    private LocalDate deadline;
    private String manager_Id;
}
