package com.app.taskmanagement.controller;

import com.app.taskmanagement.requestdto.ProjectRequestDto;
import com.app.taskmanagement.responsedto.ProjectResponseDto;
import com.app.taskmanagement.services.ProjectServices;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/task_management/project")
@RequiredArgsConstructor
@Validated
public class ProjectController {
    private final ProjectServices projectServices;
    @PostMapping
    @PreAuthorize("ROLE_ADMIN")
    public ResponseEntity<ProjectResponseDto> addProjects(@Valid @RequestBody ProjectRequestDto dto){
        return ResponseEntity.status(HttpStatus.CREATED).body(projectServices.addProjects(dto));
    }

    @PutMapping
    @PreAuthorize("ROLE_ADMIN")
    public ResponseEntity<ProjectResponseDto> updateProject(@Valid @RequestBody ProjectRequestDto dto, @RequestParam String id){
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(
                projectServices.update(dto,id)
        );
    }

    @PreAuthorize("ROLE_ADMIN")
    @GetMapping
    public ResponseEntity<ProjectResponseDto> get(@RequestParam("id") String id){
        return ResponseEntity.ok(projectServices.get(id));
    }

    @PreAuthorize("ROLE_ADMIN")
    @DeleteMapping
    public ResponseEntity<?> delete(@RequestParam("id") String id){
        return ResponseEntity.status(HttpStatus.ACCEPTED).build();
    }

    @GetMapping("/all")
    @PreAuthorize("ROLE_ADMIN")
    public ResponseEntity<List<ProjectResponseDto>> getAll(){
        return ResponseEntity.ok(projectServices.listOfProjects());
    }
}
