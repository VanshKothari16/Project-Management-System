package com.app.taskmanagement.controller;

import com.app.taskmanagement.requestdto.CommitmentRequestDto;
import com.app.taskmanagement.responsedto.CommitmentResponseDto;
import com.app.taskmanagement.services.CommitmentServices;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/task_management/commitments")
@RequiredArgsConstructor
@Validated
public class CommitmentController {
    private final CommitmentServices commitmentServices;

    @PreAuthorize("hasAnyAuthority('ROLE_EMPLOYEE','ROLE_MANAGER')")
    @PostMapping
    public ResponseEntity<CommitmentResponseDto> addCommits(@Valid @RequestBody CommitmentRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                commitmentServices.addCommits(dto)
        );
    }

    @PreAuthorize("hasAnyAuthority('ROLE_EMPLOYEE','ROLE_MANAGER')")
    @PutMapping
    public ResponseEntity<CommitmentResponseDto> updateCommits(@Valid @RequestBody CommitmentRequestDto dto, @RequestParam String id) {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(
                commitmentServices.editCommits(dto, id)
        );
    }

    @PreAuthorize("hasAnyAuthority('ROLE_EMPLOYEE','ROLE_MANAGER')")
    @GetMapping
    public ResponseEntity<Page<CommitmentResponseDto>> getAllCommitsOfTask(
            @RequestParam String taskId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "15") int size) {

        return ResponseEntity.ok(
                commitmentServices.getAllCommitmentsOfTask(taskId, page, size)
        );
    }


    @PreAuthorize("hasAnyAuthority('ROLE_EMPLOYEE','ROLE_MANAGER')")
    @DeleteMapping
    public ResponseEntity<?> deleteCommits(@RequestParam String commitId) {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(
                "Successfully Deleted!"
        );
    }
}
