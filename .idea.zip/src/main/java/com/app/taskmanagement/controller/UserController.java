package com.app.taskmanagement.controller;

import com.app.taskmanagement.requestdto.LoginDto;
import com.app.taskmanagement.requestdto.UserRequestDto;
import com.app.taskmanagement.responsedto.UserResponseDto;
import com.app.taskmanagement.services.UserServices;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/task_management/user")
public class UserController {
    private final UserServices userServices;

    public UserController(UserServices userServices) {
        this.userServices = userServices;
    }

    @PostMapping("/register")
    public ResponseEntity<UserResponseDto> register(@RequestBody UserRequestDto requestDto){
        UserResponseDto user=userServices.register(requestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(user);
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginDto loginDto){
        String jwtToken=userServices.login(loginDto);
        return ResponseEntity.ok(jwtToken);
    }
}
