package com.app.taskmanagement.repository;

import com.app.taskmanagement.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, String> {

    @Query(value = "FROM Employee e where e.email=:email")
    public Optional<Employee> findByEmail(@Param("email") String email);

    @Query("Select SIZE(e) from Employee e where e.projects.id=:id")
    public Object findTotalEmployeeInProject(@Param("id") String id);

    @Query("Select e.email from Employee e where e.projects.id=:id")
    public List<String> findAllEmails(@Param("id") String projectId);
}
