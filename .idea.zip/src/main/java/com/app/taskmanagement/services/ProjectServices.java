package com.app.taskmanagement.services;

import com.app.taskmanagement.entity.Employee;
import com.app.taskmanagement.entity.Projects;
import com.app.taskmanagement.entity.Task;
import com.app.taskmanagement.entity.User;
import com.app.taskmanagement.enums.Role;
import com.app.taskmanagement.enums.Status;
import com.app.taskmanagement.repository.EmployeeRepository;
import com.app.taskmanagement.repository.ProjectRepository;
import com.app.taskmanagement.repository.TaskRepository;
import com.app.taskmanagement.repository.UserRepository;
import com.app.taskmanagement.requestdto.ProjectRequestDto;
import com.app.taskmanagement.responsedto.ProjectResponseDto;
import com.app.taskmanagement.utils.Mapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProjectServices {
    private final ProjectRepository projectRepository;
    private final EmployeeRepository employeeRepository;
    private final UserRepository userRepository;
    private final TaskRepository taskRepository;

    /**
     * First verify, the user which calls addProjects is it "Admin" that is done in Controller via @PreAuthorize().
     * Verify, does it is duplicate project. If yes, throw exception.
     * Find Employee via id provided in dto.
     * Make that employee as Manager and add it in List of Projects Entity.
     * Set company field of the Project Entity
     * Save it in Database.
     * @param dto
     * @return ProjectResponseDto
     */
    @Transactional
    public ProjectResponseDto addProjects(ProjectRequestDto dto){
        User admin=getCurrentUser();
        projectRepository.findByNameAndEmail(dto.getName(),admin.getEmail()).ifPresent(
                (e)->{
                    throw new RuntimeException("Duplicate Project Found!");
                }
        );
        if(dto.getDeadline().isBefore(LocalDate.now()))
            throw new RuntimeException("Deadline of Project must be after "+LocalDate.now());
        Projects projects= Mapper.toProjectEntity(dto);

        Employee manager=employeeRepository.findById(dto.getManager_Id()).orElseThrow(
                ()->new RuntimeException("Enter Valid Manager Id!")
        );
        projects.setManager(manager);
        manager.setRole(Role.MANAGER);
        projects.setCompany(manager.getCompany());

        projects=projectRepository.save(projects);
        manager.setProject(projects);
        return Mapper.toProjectResponseDto(projects,manager);
    }

    @Transactional
    public ProjectResponseDto update(ProjectRequestDto dto,String id){
        User admin=getCurrentUser();
        Projects p1=projectRepository.findById(id).orElseThrow(
                ()->{throw new RuntimeException("Project doesn't exist");}
        );

        if(p1.getCompany().getAdmin().getEmail()!=admin.getEmail())
            throw new RuntimeException("Company doesn't exist!");

        if(dto.getDeadline().isBefore(LocalDate.now())) throw new RuntimeException("Deadline of Project must be after "+LocalDate.now());

        p1.setName(dto.getName());
        p1.setDeadline(dto.getDeadline());
        p1.setDescription(dto.getDescription());

        projectRepository.flush();
        return Mapper.toProjectResponseDto(p1,p1.getManager());
    }

    public ProjectResponseDto get(String id){
        Projects p1=projectRepository.findById(id).orElseThrow(
                ()->new RuntimeException("Invalid Project Id")
        );

        User admin=getCurrentUser();
        if(p1.getCompany().getAdmin().getEmail()!=admin.getEmail())
            throw new RuntimeException("Project doesn't exist!");

        return Mapper.toProjectResponseDto(p1,p1.getManager());
    }

    public void delete(String id){
        Projects p1=projectRepository.findById(id).orElseThrow(
                ()->new RuntimeException("Invalid Project Id")
        );

        User admin=getCurrentUser();
        if(p1.getCompany().getAdmin().getEmail()!=admin.getEmail())
            throw new RuntimeException("Project doesn't exist!");

        projectRepository.delete(p1);
    }

    public List<ProjectResponseDto> listOfProjects(){
        User admin=getCurrentUser();
        return projectRepository.findAllByEmail(admin.getEmail()).stream().map(
                (e)->Mapper.toProjectResponseDto(e,e.getManager())
        ).toList();
    }

    private User getCurrentUser(){
        UserDetails userDetails=(UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userRepository.findByEmail(userDetails.getUsername());
    }

    //Implicitly called by TaskServices.
    public void changeStatus(String projectId){
        Projects p1=projectRepository.findById(projectId).orElseThrow(
                ()->new RuntimeException("Invalid Project Id")
        );

        List<Task> task=taskRepository.findTaskByStatusAndProjects(Status.IN_PROGRESS,projectId);
        List<Task> task1=taskRepository.findTaskByStatusAndProjects(Status.TO_DO,projectId);
        if(task.isEmpty() && task1.isEmpty()) {
            p1.setStatus(Status.COMPLETED);
            return;
        }

        if(!task.isEmpty()) p1.setStatus(Status.IN_PROGRESS);
    }
}
