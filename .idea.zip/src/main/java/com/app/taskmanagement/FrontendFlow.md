### /*****************************************************
### FrontEnd Flow
### ****************************************************/

**COMPLETED**
1. Employee/Admin/Manager opens the app by default it will find Login Page with username
and password. If they don't have account there will be Registration as Employee / Register as 
Company.

Registration Employee:
* name
* email
* password
* phone
* companyCode

Registration Company:
* name
* email
* password
* phone
* company_name
* occupation
* address

Login:
* Username 
* password


//ADMIN Dashboard Page
2. In Admin dashboard,It will be able to see a List of **Projects** created by Admin with (+) button at the
bottom right which add projects. 
ii) On click of each projects, it will be able to see Count of Total Managers, 
TotalEmployee, To-Do, In-Progress, Done, Overdue task, and Remaining Days for deadline.
iii) On click of Total Employee it will be able to see a list of Employee with details,
To-Do all the ToDo task only with its details, same with In-Progress, Done and Overdue.
On click of manager it will see a List of Managers on click of each respective details will
found.

Projects:
* name
* description
* managerId
* deadline


//Manager Dashboard Page
3. In Manager Dashboard, there will be ToDo, InProgress, Completed and OverDue panel which
shows a Todo Task, Inprogress Task, CompletedTask and OverDue Task respectively. There will 
one more, profile panel where email can't be updated.

ii) At the bottom right there will a + button in all four Task panels that allows to add Task.

iii) On click of each task, it will be able to see all commitment i.e. Activity log in grid view with Date,
commitment, employee name/email. At the below part there will be "Assign employee" button which assign 
the currently open task to the employee and "Completed" button.

Task:
* title
* description
* dueDate
* priority
* status

Activity Log:
* commitments


// Employee Dashboard Page
**COMPLETED**
4. Employee will be able to see To-Do, In-Progress, Done and Profile Panel of assigned Task. 

i) If employee clicks on To-Do or In-Progress Task, there will be a buttons at bottom part, 
        "Commitments". On Click of Commitments they will add commit/logs in text format. 

ii) If there are at least one commit, task will become In-Progress from To-DO. On click of 
        In-Progress task they will see an Activity log in time line format with same buttons at below part.
        Each Activity log will have commitments, date and employeeName.
    
iii) On Click of Completed Task, they will just see commitments, button commitment will not be shown.
iv) On click of profile they can edit their profile detail except email and no relations field are shown. 

