package com.app.taskmanagement.services;

import com.app.taskmanagement.entity.Company;
import com.app.taskmanagement.entity.Employee;
import com.app.taskmanagement.entity.Projects;
import com.app.taskmanagement.entity.User;
import com.app.taskmanagement.repository.CompanyRepository;
import com.app.taskmanagement.repository.EmployeeRepository;
import com.app.taskmanagement.repository.UserRepository;
import com.app.taskmanagement.requestdto.EmployeeRequestDto;
import com.app.taskmanagement.responsedto.EmployeeResponseDto;
import com.app.taskmanagement.utils.Mapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EmployeeServices {
    private final EmployeeRepository employeeRepository;
    private final CompanyRepository companyRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;

    public EmployeeResponseDto addEmployee(EmployeeRequestDto dto) {
        employeeRepository.findByEmail(dto.getEmail()).ifPresent(
                (e) -> {
                    throw new RuntimeException("You already have an Account");
                }
        );

        Company company = companyRepository.findById(dto.getCompanyCode()).orElseThrow(
                () -> new RuntimeException("Enter valid company code!")
        );

        Employee employee = Mapper.toEmployeeEntity(dto);
        employee.setCompany(company);
        employee.setPassword(encodePassword(employee.getPassword()));

        employee = employeeRepository.save(employee);
        return Mapper.toEmployeeResponseDto(employee);
    }

    @Transactional
    public EmployeeResponseDto update(EmployeeRequestDto dto) {
        Employee emp = employeeRepository.findByEmail(dto.getEmail()).orElseThrow(
                () -> {
                    throw new RuntimeException("Invalid Email Id");
                }
        );

        Employee login = getCurrentUser();

        if (!login.getEmail().equals(emp.getEmail())) throw new AccessDeniedException("UnRegistered Employee");

        emp.setName(dto.getName());
        emp.setMobileNo(dto.getPhone());
        emp.setQualification(dto.getQualification());
        emp.setSpecialization(dto.getSpecialization());

        return Mapper.toEmployeeResponseDto(emp);
    }

    public EmployeeResponseDto getEmployee() {
        Employee employee = getCurrentUser();
        return Mapper.toEmployeeResponseDto(
                employeeRepository.findByEmail(employee.getEmail()).orElseThrow(
                        () -> new RuntimeException("Invalid Email id")
                )
        );
    }

    public List<String> getAllEmployeeEmails() {
        Employee e1 = getCurrentUser();
        return employeeRepository.findAllEmails(
                e1.getProject().getId()
        );
    }

    private Employee getCurrentUser() {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return employeeRepository.findByEmail(userDetails.getUsername()).orElseThrow(
                () -> new RuntimeException("Employee Couldn't found!")
        );
    }

    private String encodePassword(String password) {
        return passwordEncoder.encode(password);
    }

}
