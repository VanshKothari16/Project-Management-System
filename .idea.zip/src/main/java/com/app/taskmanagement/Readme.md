# User Registration & Login System (Spring Boot + JWT)

A Spring Boot backend that handles **User Registration** and **User Login**, secured using **Spring Security** and **JWT (JSON Web Token)** based authentication. On successful login, the user receives a JWT token which must be used to access protected endpoints.

---

## 📌 Features

- User Registration with password encryption
- User Login with JWT token generation
- Custom `UserDetailsServiceImpl` for Spring Security authentication
- Global Exception Handling
- Hibernate/JPA based entity persistence
- Clean layered architecture (Controller → Service → Repository)

---

## 🗂️ Project Structure

```
src/main/java/.../
│
├── config/            → Spring Security configuration, Hibernate config
├── controller/         → REST controllers exposing Auth APIs (Register, Login)
├── entity/              → Entity: User
├── exceptionhandler/     → Global exception handling (@ControllerAdvice)
├── repository/            → Base Repository, User Repository
├── requestdto/             → Incoming request DTOs (UserRequestDto, LoginDto)
├── responsedto/             → Outgoing response DTOs (UserResponseDto)
├── services/                 → Business logic (UserService,  UserDetailsServiceImpl)
└── utils/                     → Mapper, JwtServices
```

### Folder Responsibilities

| Folder | Purpose |
|---|---|
| **config** | Contains `SecurityConfig` (Spring Security filter chain, password encoder) and Hibernate configuration |
| **controller** | Exposes REST endpoints: `/api/register`, `/api/login` |
| **entity** | Entity classes mapped to database tables (e.g. `User`) |
| **exceptionhandler** | Centralized exception handling using `@RestControllerAdvice` / `@ExceptionHandler` |
| **repository** | BaseRepositoy class for DB operations and User Repository |
| **requestdto** | DTOs used to accept incoming request bodies |
| **responsedto** | DTOs used to structure API responses |
| **services** | Core business logic including `UserDetailsServiceImpl` |
| **utils** | Common reusable utility/helper methods including JWT generation/validation|

---

## 🔐 Security Overview

- Passwords are stored using **BCryptPasswordEncoder**
- Authentication is stateless (no server-side session) — **JWT-based**
- `UserDetailsServiceImpl` loads user data from DB for Spring Security's `AuthenticationProvider`
- `JwtService` handles:
  - Generating JWT token after successful login
  - Extracting claims (username/email, expiration, etc.)
  - Validating token signature & expiry

---

## 🚀 API Endpoints

### 1️⃣ User Registration

**Endpoint:** `POST /api/register`

**Request Body:** `UserRequestDto`

```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "SecurePassword123",
  "phone": "9876543210"
}
```

**Response:** `UserResponseDto` (registered user details, without password)
```json
{
  "id":"1"
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "9876543210"
}
```

---

### 2️⃣ User Login

**Endpoint:** `POST /api/login`

**Request Body:** `LoginDto`

```json
{
  "username": "john@example.com",
  "password": "SecurePassword123"
}
```

**Response:** JWT Token

```
   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
```

---

## 🔑 Using the JWT Token

Once you receive the token from `/api/login`, pass it in the `Authorization` header for all protected endpoints:

```
Authorization: Bearer <your_jwt_token>
```

---

## 🛠️ Tech Stack

- Java
- Spring Boot
- Spring Security
- Hibernate / Spring Data JPA
- JWT (jjwt / java-jwt library)
- Lombok (if used)
- MySQL / PostgreSQL (whichever DB configured)

---

## ⚙️ Setup & Run

1. Clone the repository
   ```bash
   git clone <repo-url>
   ```
2. Configure database credentials in `application.properties` / `application.yml`
3. Build the project
   ```bash
   mvn clean install
   ```
4. Run the application
   ```bash
   mvn spring-boot:run
   ```
5. Application will start on: `http://localhost:8080`

---

## 📝 Notes to Self (Why This Repo Exists)

- This repo is the **base authentication module** — Registration + Login + JWT — meant to be reused/plugged into future projects.
- Core reusable pieces: `SecurityConfig`, `JwtService`, `UserDetailsServiceImpl`, JWT Filter.
- Only these folders are published: `config`, `controller`, `entity`, `exceptionhandler`, `repository`, `requestdto`, `responsedto`, `services`, `utils`.
- Anything outside this scope (e.g. business-specific modules) is intentionally excluded from this repo.

---
