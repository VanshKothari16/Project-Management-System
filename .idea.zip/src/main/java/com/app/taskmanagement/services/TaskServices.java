package com.app.taskmanagement.services;

import com.app.taskmanagement.entity.Employee;
import com.app.taskmanagement.entity.Task;
import com.app.taskmanagement.entity.User;
import com.app.taskmanagement.enums.Status;
import com.app.taskmanagement.repository.EmployeeRepository;
import com.app.taskmanagement.repository.TaskRepository;
import com.app.taskmanagement.requestdto.TaskRequestDto;
import com.app.taskmanagement.responsedto.AdminDashboardDto;
import com.app.taskmanagement.responsedto.ManagerTaskResponseDto;
import com.app.taskmanagement.responsedto.TaskResponseDto;
import com.app.taskmanagement.utils.Mapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TaskServices {
    private final TaskRepository taskRepository;
    private final EmployeeRepository employeeRepository;
    private final ProjectServices projectServices;

    /**
     * Verify, addTask() who calls is it Manager which is did at Controller level by @PreAuthorize
     * Verify does any Duplicate task exist!
     *
     * @param taskRequestdto
     * @return TaskResponseDto
     */
    @Transactional
    public TaskResponseDto addTask(TaskRequestDto taskRequestdto) {
        Employee manager = getCurrentUser();
        taskRepository.findByTitleAndProjects(taskRequestdto.getTitle(), manager.getProject().getId())
                .ifPresent(
                        (e) -> {
                            throw new RuntimeException("Task already Exist in Project!");
                        }
                );

        if (taskRequestdto.getDueDate().isBefore(LocalDate.now()))
            throw new RuntimeException("Deadline must be after " + LocalDate.now());
        Task t1 = Mapper.toTaskEntity(taskRequestdto);
        t1.setProjects(manager.getProject());

        t1 = taskRepository.save(t1);
        return Mapper.toTaskReponseDto(t1);
    }

    public TaskResponseDto updateTask(TaskRequestDto dto, String id) {
        Task t1 = taskRepository.findById(id).orElseThrow(
                () -> new RuntimeException("Task doesn't exist!")
        );

        User manager = getCurrentUser();
        if (t1.getProjects().getManager().getEmail() != manager.getEmail())
            throw new RuntimeException("Task doesn't exist in your profile!");

        t1.setTitle(dto.getTitle());
        t1.setDescription(dto.getDescription());
        t1.setDueDate(dto.getDueDate());
        t1.setPriority(dto.getPriority());

        taskRepository.flush();
        return Mapper.toTaskReponseDto(t1);
    }

    public TaskResponseDto getTask(String id) {
        Task t1 = taskRepository.findById(id).orElseThrow(
                () -> new RuntimeException("Task doesn't exist!")
        );

        User manager = getCurrentUser();
        if (t1.getProjects().getManager().getEmail() != manager.getEmail())
            throw new RuntimeException("Task doesn't exist in your profile!");
        return Mapper.toTaskReponseDto(t1);
    }

    public void deleteTask(String id) {
        Task t1 = taskRepository.findById(id).orElseThrow(
                () -> new RuntimeException("Task doesn't exist!")
        );

        User manager = getCurrentUser();
        if (t1.getProjects().getManager().getEmail() != manager.getEmail())
            throw new RuntimeException("Task doesn't exist in your profile!");

        taskRepository.delete(t1);
    }

    @Transactional
    public String assignTaskToEmployee(String taskId, String employeeEmail) {
        Task t1 = taskRepository.findById(taskId).orElseThrow(() -> {
            throw new RuntimeException("Task doesn't found!");
        });
        Employee employee = employeeRepository.findByEmail(employeeEmail).orElseThrow(() -> new RuntimeException("Invalid Email"));

        employee.getTask().add(t1);
        t1.getEmployee().add(employee);

        return "Task " + t1.getTitle() + "  is assigned successfully to " + employee.getName();
    }

    //****************** ManagerDashboard *******************
    public List<ManagerTaskResponseDto> findAll() {
        Employee manager = getCurrentUser();
        List<Task> tasks = taskRepository.findTaskByProjects(manager.getProject().getId());

        return tasks.stream().map(task -> {
            // Map base TaskResponseDto
            TaskResponseDto baseDto = Mapper.toTaskReponseDto(task);
            // Build ManagerTaskResponseDto using SuperBuilder
            return ManagerTaskResponseDto.builder()
                    .id(baseDto.getId())
                    .title(baseDto.getTitle())
                    .description(baseDto.getDescription())
                    .dueDate(baseDto.getDueDate())
                    .priority(baseDto.getPriority())
                    .status(baseDto.getStatus())
                    .projectName(baseDto.getProjectName())
                    .employee(baseDto.getEmployee())
                    .totalCommitments(task.getCommitments() != null ? task.getCommitments().size() : 0)
                    .build();
        }).collect(Collectors.toList());
    }

    public List<ManagerTaskResponseDto> findAllOverdueTask() {
        List<ManagerTaskResponseDto> overdueTask = new ArrayList<>();
        findAll().stream().forEach(
                (e) -> {
                    if (e.getDueDate().isBefore(LocalDate.now())) overdueTask.add(e);
                }
        );
        return overdueTask;
    }

    public List<ManagerTaskResponseDto> findAllTaskByStatus(Status status) {
        List<ManagerTaskResponseDto> statusTask = new ArrayList<>();
        findAll().stream().forEach(
                (e) -> {
                    if (e.getStatus() == status) statusTask.add(e);
                }
        );
        return statusTask;
    }

    public AdminDashboardDto getAdminDashboardDto(){
        Employee admin = getCurrentUser();
        Object count=employeeRepository.findTotalEmployeeInProject(admin.getProject().getId());

        return AdminDashboardDto.builder()
                .totalManager(1)
                .totalEmployee((Integer) count)
                .toDoTask(findAllTaskByStatus(Status.TO_DO).size())
                .inProgressTask(findAllTaskByStatus(Status.IN_PROGRESS).size())
                .completedTask(findAllTaskByStatus(Status.COMPLETED).size())
                .overDueTask(findAllOverdueTask().size())
                .deadline(admin.getProject().getDeadline())
                .build();
    }

    private Employee getCurrentUser() {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return employeeRepository.findByEmail(userDetails.getUsername()).get();
    }

    //********* Employee Dashboard related Services ********
    public List<TaskResponseDto> getTaskOfEmployee() {
        User employee = getCurrentUser();
        return taskRepository.findTaskOfEmployee(employee.getEmail()).stream().map(
                Mapper::toTaskReponseDto
        ).toList();
    }

    public List<TaskResponseDto> getTaskOfEmployeeByStatus(Status status) {
        List<TaskResponseDto> statusTaskList = new ArrayList<>();
        getTaskOfEmployee().stream().forEach(
                (e) -> {
                    if (e.getStatus() == status) statusTaskList.add(e);
                }
        );
        return statusTaskList;
    }

    //********** It will do only by Manager **********
    public void markItAsCompleted(String id) {
        User manager = getCurrentUser();
        Task t1 = taskRepository.findById(id).orElseThrow(
                () -> new RuntimeException("Invalid Task id.")
        );
        if (!t1.getProjects().getManager().getEmail().equals(manager.getEmail())) throw new RuntimeException(
                "Task doesn't Exist!"
        );
        t1.setStatus(Status.COMPLETED);
        projectServices.changeStatus(t1.getProjects().getId());
    }

    //Implicitly called by ActivityLog Services
    @Transactional
    public void changeStatusToIn_Progress(String id) {
        Task t1 = taskRepository.findById(id).orElseThrow(
                () -> new RuntimeException("Invalid Task Id.")
        );
        t1.setStatus(Status.IN_PROGRESS);
        projectServices.changeStatus(t1.getProjects().getId());
    }
}
