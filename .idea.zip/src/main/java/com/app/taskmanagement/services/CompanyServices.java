package com.app.taskmanagement.services;

import com.app.taskmanagement.entity.Company;
import com.app.taskmanagement.entity.User;
import com.app.taskmanagement.enums.Role;
import com.app.taskmanagement.repository.CompanyRepository;
import com.app.taskmanagement.repository.UserRepository;
import com.app.taskmanagement.requestdto.CompanyRequestDto;
import com.app.taskmanagement.requestdto.UserRequestDto;
import com.app.taskmanagement.responsedto.CompanyResponseDto;
import com.app.taskmanagement.responsedto.UserResponseDto;
import com.app.taskmanagement.utils.Mapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class CompanyServices {
    private final CompanyRepository companyRepository;
    private final UserRepository userRepository;
    private final UserServices userServices;

    @Transactional
    public CompanyResponseDto register(CompanyRequestDto companyRequestDto, UserRequestDto userRequestDto){
        UserResponseDto userResponseDto=userServices.register(userRequestDto);

        Company existCompany=companyRepository.findByNameAndEmail(companyRequestDto.getCompanyName(),userResponseDto.getEmail());
        if(existCompany!=null) throw new RuntimeException("Duplicate Company!");

        Company company=Mapper.toCompanyEntity(companyRequestDto);

        User admin=userRepository.findByEmail(userRequestDto.getEmail());
        admin.setRole(Role.ADMIN);
        company.setAdmin(admin);


        company=companyRepository.save(company);
        companyRepository.flush();
        return Mapper.toCompanyResponseDto(company);
    }
}

